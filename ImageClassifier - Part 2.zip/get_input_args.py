#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Image Classifier - Part 2
#                                                                             
# PROGRAMMER: Oscar Perez Jr
# DATE CREATED: 05/11/2021                                  
# REVISED DATE: 
# PURPOSE: Create functions for retrieving the input vars for train and predict
#
##
# Imports python modules
import argparse

# 
def get_train_input_args():
    """
    Retrieves and parses up to 7 command line arguments provided by the user when
    they run the program from a terminal window. This function uses Python's 
    argparse module to create and define these command line arguments. If 
    the user fails to provide some or all of the arguments, then the default 
    values are used for the missing arguments. 
    Command Line Arguments:
      1. First argument is mandatory and must be provided by the user to provide directory for training images
      2. CNN Model Architecture as --arch with default value 'resnet50'
      3. Directory to save checkpoints as --save_dir with default value '/home/workspace/ImageClassifier/output/'
      4. Training learning rate as --learning_rate with default value 0.01
      5. Training hidden units as --hidden_units with default value 512
      6. Training epochs as --epochs with default value 3
      7. Flag to use GPU as --gpu with default of cpu if not specified

    This function returns these arguments as an ArgumentParser object.
    Parameters:
     None - simply using argparse module to create & store command line arguments
    Returns:
     parse_args() -data structure that stores the command line arguments object  
    """
    # Create Parse using ArgumentParser
    parser = argparse.ArgumentParser()
    
    # Create 7 command line arguments as mentioned above using add_argument() from ArguementParser method
    parser.add_argument('imagedir', type = str, default = '/home/workspace/ImageClassifier/flowers/train/', help = 'Training learning rate') 
    parser.add_argument('--arch', type = str, default = 'resnet50', choices=['vgg13', 'resnet50'], help = 'path to the folder of images') 
    parser.add_argument('--save_dir', type = str, default = '/home/workspace/ImageClassifier/output/', help = 'the CNN model architecture') 
    parser.add_argument('--learning_rate', type = float, default = 0.01, help = 'Training learning rate') 
    parser.add_argument('--hidden_units', type = int, default = 512, help = 'Training hidden units') 
    parser.add_argument('--epochs', type = int, default = 3, help = 'Training epochs') 
    parser.add_argument('--gpu', action='store_true', help = 'Use GPU when specified') 
  
    return parser.parse_args()

# Print args to console
def check_train_command_line_arguments(in_arg):
    if in_arg is None:
        print("* Doesn't Check the Command Line Arguments because 'get_train_input_args' hasn't been defined.")
    else:
        # prints command line agrs
        print("Command Line Arguments:",
              "\n   dir =", in_arg.imagedir, 
              "\n   arch =", in_arg.arch, 
              "\n   save_dir =", in_arg.save_dir, 
              "\n   learning_rate =", in_arg.learning_rate, 
              "\n   hidden_units =", in_arg.hidden_units, 
              "\n   epochs =", in_arg.epochs, 
              "\n   gpu =", in_arg.gpu)

# 
def get_predict_input_args():
    """
    Retrieves and parses up to 5 command line arguments provided by the user when
    they run the program from a terminal window. This function uses Python's 
    argparse module to create and define these command line arguments. If 
    the user fails to provide some or all of the arguments, then the default 
    values are used for the missing arguments. 
    Command Line Arguments:
      1. First argument is mandatory and must be provided by the user to provide image to classify
      2. Second argument is mandaotory and must be provided by the user to provide checkpoint
      3. Top K most likely classes as --top_k with default value 3
      4. Category to real names as --category_names with default value 'cat_to_name.json'
      5. Flat to use GPU as --gpu with default of cpu if not specified

    This function returns these arguments as an ArgumentParser object.
    Parameters:
     None - simply using argparse module to create & store command line arguments
    Returns:
     parse_args() -data structure that stores the command line arguments object  
    """
    # Create Parse using ArgumentParser
    parser = argparse.ArgumentParser()
    
    # Create 5 command line arguments as mentioned above using add_argument() from ArguementParser method
    parser.add_argument('image', type = str, help = 'Image to classify') 
    parser.add_argument('checkpoint', type = str, help = 'Checkpoint file') 
    parser.add_argument('--top_k', type = int, default = 3, help = 'Top K most likely classes') 
    parser.add_argument('--category_names', type = str, default = 'cat_to_name.json', help = 'Category to real names') 
    parser.add_argument('--gpu', action='store_true', help = 'Use GPU when specified') 
  
    return parser.parse_args()

# Print args to console
def check_predict_command_line_arguments(in_arg):
    if in_arg is None:
        print("* Doesn't Check the Command Line Arguments because 'get_train_input_args' hasn't been defined.")
    else:
        # prints command line agrs
        print("Command Line Arguments:",
              "\n   image =", in_arg.image, 
              "\n   checkpoint =", in_arg.checkpoint, 
              "\n   top_k =", in_arg.top_k, 
              "\n   category_names =", in_arg.category_names, 
              "\n   gpu =", in_arg.gpu)

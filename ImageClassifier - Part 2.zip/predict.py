#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Image Classifier - Part 2
#
# PROGRAMMER: Oscar Perez Jr
# DATE CREATED: 06/27/2021 
# PURPOSE: Train a new network on a data set
#
# Use argparse Expected Call with <> indicating expected user input:
#      python predict.py <single image> <checkpoint>
#             --top_k <return top K most likely classes>
#             --category_names <categories to real names>
#             --gpu <use gpu when specified>

#   Example call:
#    python predict.py image_file checkpoint
##

# Imports python modules
from time import time, sleep
from get_input_args import get_predict_input_args
from get_input_args import check_predict_command_line_arguments
import json
from predict_helpers import predict
import torch
from torch import nn, optim
import torch.nn.functional as F
import torchvision.models as models

# Main program function defined below
def main():
    # Measures total program runtime by collecting start time
    start_time = time()

    in_arg = get_predict_input_args()

    # Function that checks command line arguments using in_arg  
    check_predict_command_line_arguments(in_arg)

    # Once we have good cmd line args, set up or local vars for training
    img_file = in_arg.image
    checkpoint_file = in_arg.checkpoint 
    top_k = in_arg.top_k 
    category_names = in_arg.category_names 
    gpu = in_arg.gpu

    # get arch and hidden_units from the checkpoint file name
    filename = checkpoint_file.split("_")
    arch = filename[len(filename)-2]
    tmp = filename[len(filename)-1].split(".")[0]
    hidden_units = int(float(tmp))
    print(">>>>> arch " + arch)
    print(">>>>> hidden_units " + str(hidden_units))

    #--------------------------------------------------------------------------------------------
    # Load the category names 
    #--------------------------------------------------------------------------------------------
    with open(category_names, 'r') as f:
        cat_to_name = json.load(f)
        
    #--------------------------------------------------------------------------------------------
    # Create a model and load checkpoint
    #--------------------------------------------------------------------------------------------
    # Create model with gradients off 
    if arch == 'resnet50':
        model = models.resnet50(pretrained=True)
    else:
        model = models.vgg13(pretrained=True)
    for param in model.parameters():
        param.requires_grad = False

    # Create classifier
    classifier = nn.Sequential(nn.Linear(2048, hidden_units),
                              nn.ReLU(),
                              nn.Dropout(p=0.2),
                              nn.Linear(hidden_units, 102),
                              nn.LogSoftmax(dim=1))

    model.fc = classifier
    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.fc.parameters(), lr=0.001)

 
    # Load model with checkpoint
    checkpoint = torch.load(checkpoint_file)
    model.load_state_dict(checkpoint['state_dict'])
    model.class_to_idx = checkpoint['class_to_idx']

    # Setup flag to run based on whether GPU is enabled
    device = torch.device("cuda" if gpu else "cpu")
    print(">>>>> cuda_is_available " + str(torch.cuda.is_available()))

    model.to(device)
    #--------------------------------------------------------------------------------------------
    # Perform prediction
    #--------------------------------------------------------------------------------------------
    probs, classes = predict(img_file, model, device, cat_to_name, top_k)
  
    # Measure total program runtime by collecting end time
    end_time = time()
    
    # Computes overall runtime in seconds & prints it in hh:mm:ss format
    tot_time = end_time - start_time #calculate difference between end time and start time
    #print("tot >>>>>" + str(tot_time) + "\n")
    print("\n** Total Elapsed Runtime:",
          str(int((tot_time/3600)))+":"+str(int((tot_time%3600)/60))+":"
          +str(int((tot_time%3600)%60)) )
    

# Call to main function to run the program
if __name__ == "__main__":
    main()

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Image Classifier - Part 2
#
# PROGRAMMER: Oscar Perez Jr
# DATE CREATED: 06/27/2021 
# PURPOSE: Train a new network on a data set
#
# Use argparse Expected Call with <> indicating expected user input:
#      python train.py <directory with images> 
#             --arch <model>
#             --save_dir <directory to save checkpoints>
#             --learning_rate <learning rate for training>
#             --hidden_units <number of hidden units for training>
#             --epochs <number of epoch for training>
#             --gpu <use gpu when specified>

#   Example call:
#    python train.py data_directory
##

# Imports python modules
from time import time, sleep
from get_input_args import get_train_input_args
from get_input_args import check_train_command_line_arguments
import torch
from torchvision import datasets, transforms
import json
from torch import nn, optim
import torchvision.models as models

# Main program function defined below
def main():
    # Measures total program runtime by collecting start time
    start_time = time()

    in_arg = get_train_input_args()

    # Function that checks command line arguments using in_arg  
    check_train_command_line_arguments(in_arg)

    # Once we have good cmd line args, set up or local vars for training
    train_dir = in_arg.imagedir
    arch = in_arg.arch 
    save_dir = in_arg.save_dir 
    learning_rate = in_arg.learning_rate 
    hidden_units = in_arg.hidden_units 
    epochs = in_arg.epochs
    gpu = in_arg.gpu
    
    # test folder is for stats output
    test_dir = "/home/workspace/ImageClassifier/flowers/test/"
 
    #--------------------------------------------------------------------------------------------
    # Load the data - define transforms for the training and testing sets
    #--------------------------------------------------------------------------------------------
    train_transforms = transforms.Compose((transforms.RandomRotation(30),
                                          transforms.RandomResizedCrop(224),
                                          transforms.RandomHorizontalFlip(),
                                          transforms.ToTensor()))
    train_datasets = datasets.ImageFolder(train_dir, transform=train_transforms)
    trainloaders = torch.utils.data.DataLoader(train_datasets, batch_size=64, shuffle=True)

    test_transforms = transforms.Compose((transforms.Resize(256),
                                          transforms.CenterCrop(224),
                                          transforms.ToTensor()))
    test_datasets = datasets.ImageFolder(test_dir, transform=test_transforms)
    testloaders = torch.utils.data.DataLoader(test_datasets, batch_size=32)       

    #--------------------------------------------------------------------------------------------
    # Build and train the classifier
    #--------------------------------------------------------------------------------------------

    # Setup flag to run based on whether GPU is enabled
    device = torch.device("cuda" if gpu else "cpu")
    print(">>>>> cuda.is_available " + str(torch.cuda.is_available())) ###############################
          
    # Create model with gradients off 
    if arch == 'resnet50':
        model = models.resnet50(pretrained=True)
        linearval = 2048
    else:
        model = models.vgg13(pretrained=True)
        linearval = 25088
    
    for param in model.parameters():
        param.requires_grad = False    

    # Create classifier
    classifier = nn.Sequential(nn.Linear(linearval, hidden_units),
                              nn.ReLU(),
                              nn.Dropout(p=0.2),
                              nn.Linear(hidden_units, 102),
                              nn.LogSoftmax(dim=1))

    criterion = nn.NLLLoss()
    if arch == 'resnet50':
        model.fc = classifier
        optimizer = optim.Adam(model.fc.parameters(), lr=learning_rate)
    else:
        model.classifier = classifier
        optimizer = optim.Adam(model.classifier.parameters(), lr=learning_rate)

    model.to(device)

    # Perform training per user defined epochs
    steps = 0
    running_loss = 0
    print_every = 10

    for epoch in range(epochs):
        print(epoch) ################################
        for images, labels in trainloaders:
            steps += 1
            print(steps) ################################
            # Move tensors to device
            images, labels = images.to(device), labels.to(device)

            optimizer.zero_grad()

            logps = model(images)
            loss = criterion(logps, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            if (steps % print_every) == 0:
                print('print every') ################################
                model.eval()
                test_loss = 0
                accuracy = 0

                for images, labels in testloaders:
                    print('test check') ################################
                    # Move tensors to device
                    images, labels = images.to(device), labels.to(device)

                    logps = model(images)
                    loss = criterion(logps, labels)
                    test_loss += loss.item()

                    # Calculate accuracy
                    ps = torch.exp(logps)
                    top_ps, top_class = ps.topk(1, dim=1)
                    equality = top_class == labels.view(*top_class.shape)
                    accuracy += torch.mean(equality.type(torch.FloatTensor)).item()

                print(f'Epoch {epoch+1}/{epochs}.. '
                     f'Train loss: {running_loss/print_every:.3f}.. '
                     f'Test loss: {test_loss/len(testloaders):.3f}.. '
                     f'Test accuracy: {accuracy/len(testloaders):.3f}.. ')

                running_loss = 0
                model.train()

    print('Training completed...')
    
    # Save checkpoint
    model.class_to_idx= train_datasets.class_to_idx
    checkpoint = {'input_size' : 2048,
                 'output_size' : 102,
                 'epochs' : epochs,
                 'hidden_layer' : hidden_units,
                 'learning_rate' : learning_rate,
                 'class_to_idx' : model.class_to_idx,
                 'state_dict' : model.state_dict()}

    #perform save
    checkpoint_file = "/home/workspace/ImageClassifier/output/checkpoint_" + arch + "_" + str(hidden_units) + ".pth"
    print(checkpoint_file)
    torch.save(checkpoint, checkpoint_file)    
    
    #--------------------------------------------------------------------------------------------
    # 
    #--------------------------------------------------------------------------------------------
    
    # Measure total program runtime by collecting end time
    end_time = time()
    
    # Computes overall runtime in seconds & prints it in hh:mm:ss format
    tot_time = end_time - start_time #calculate difference between end time and start time
    #print("tot >>>>>" + str(tot_time) + "\n")
    print("\n** Total Elapsed Runtime:",
          str(int((tot_time/3600)))+":"+str(int((tot_time%3600)/60))+":"
          +str(int((tot_time%3600)%60)) )
    

# Call to main function to run the program
if __name__ == "__main__":
    main()

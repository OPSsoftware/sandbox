#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# Image Classifier - Part 2
#                                                                             
# PROGRAMMER: Oscar Perez Jr
# DATE CREATED: 05/11/2021                                  
# REVISED DATE: 
# PURPOSE: Helper functions for predict code
#
##
# Imports python modules
import torch
from torchvision import transforms
import matplotlib.pyplot as plt
import numpy as np
import PIL

# Scales, crops, and normalizes a PIL image for a PyTorch model, returns an Numpy array
def process_image(image):
    
    # TODO: Process a PIL image for use in a PyTorch model
    in_pil = PIL.Image.open(image)
    
    #create transform
    pil_transforms = transforms.Compose([transforms.Resize(256),
                                transforms.CenterCrop(224),
                                transforms.ToTensor(),
                                transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])
    out_pil = pil_transforms(in_pil)

    return out_pil

# Predict the class (or classes) of an image using a trained deep learning model
def predict(image_path, model, device, cat_to_name, topk=5):
    
    # TODO: Implement the code to predict the class from an image file    
    image = process_image(image_path)
    
    model.to(device)
    model.eval()
    model.type(torch.FloatTensor)
    
    output = torch.exp(model(image.unsqueeze(0)))
    probs, classes = output.topk(k=topk)
    probvals = probs.detach().numpy()[0]
    classvals = classes.detach().numpy()[0]
    idx_to_class = {val: key for key, val in model.class_to_idx.items()}
    predicted_classes = [idx_to_class[idx] for idx in classvals]
    names = [cat_to_name[cat] for cat in predicted_classes]

    print('\n\nClassification Results:')
    i = 0
    for name in names:
        prob = "{:.2%}".format(probvals[i])
        print("   " + name + " " + prob)
        i = i + 1

    return probs, classes